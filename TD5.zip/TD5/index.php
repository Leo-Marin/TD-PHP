<?php
$DS = DIRECTORY_SEPARATOR;
$ROOT_FOLDER = __DIR__;
require_once "$ROOT_FOLDER"."$DS"."lib"."$DS"."File.php";
require File::build_path(["controller","routeur.php"]);
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

